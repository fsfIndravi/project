/*
 ============================================================================
 Name		: Benchmark.cpp
 Author	  : Konstantin Knizhnik
 Copyright   : GigaBASE is freeware
 Description : Main application class
 ============================================================================
 */

// INCLUDE FILES
#include <eikstart.h>
#include "BenchmarkApplication.h"

LOCAL_C CApaApplication* NewApplication()
	{
	return new CBenchmarkApplication;
	}

GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication(NewApplication);
	}

