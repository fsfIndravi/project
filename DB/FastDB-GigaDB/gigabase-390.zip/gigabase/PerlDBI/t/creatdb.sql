open 'clitest.dbs';
create table person (name    string,
	             salary  int4,
	             address string,
                     rating  real8);
create index on person.salary;
create hash on person.name;
start server 'localhost:6100' 8
