# -*- perl -*-
# $Id: Gigabase.pm,v 1.1 2008/04/04 11:02:30 knizhnik Exp $

package Bundle::DBD::Gigabase;

$VERSION = '0.1';

1;

__END__

=head1 NAME

Bundle::DBD::Gigabase - A bundle to install the DBD::Gigabase driver

=head1 SYNOPSIS

C<perl -MCPAN -e 'install Bundle::DBD::Gigabase'>

=head1 CONTENTS

DBI 1.02

Gigabase 1.05

=head1 DESCRIPTION

This bundle includes all that's needed to access Gigabase RDBMS server
via DBI emulation.

=cut
