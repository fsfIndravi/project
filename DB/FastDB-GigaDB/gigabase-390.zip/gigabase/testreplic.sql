open 'slave.dbs'
select * from Account;
exit