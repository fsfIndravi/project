import jnicli.DatabaseJNI;
import jnicli.Database;
import jnicli.Cursor;

class DbParentClass
{
    public long     imvKey = -1;

    public int 		imvIntField_1,
                    imvIntField_2,
                    imvIntField_3,
                    imvIntField_4,
                    imvIntField_5;

	public long     imvLongField_1,
                    imvLongField_2,
                    imvLongField_3,
                    imvLongField_4,
                    imvLongField_5;


    public String   imvStrField_1,
                    imvStrField_2,
                    imvStrField_3,
                    imvStrField_4,
                    imvStrField_5,
                    imvStrField_6,
                    imvStrField_7,
                    imvStrField_8,
                    imvStrField_9;

    public byte []  imvData= new byte[0];
}

class DbTestClass extends DbParentClass
{
    public int 		imvIntField_6,
                    imvIntField_7,
                    imvIntField_8,
                    imvIntField_9,
                    imvIntField_10;

	public long     imvLongField_6,
                    imvLongField_7,
                    imvLongField_8,
                    imvLongField_9,
                    imvLongField_10;


    public String   imvStrField_11,
                    imvStrField_12,
                    imvStrField_13,
                    imvStrField_14,
                    imvStrField_15,
                    imvStrField_16,
                    imvStrField_17,
                    imvStrField_18,
                    imvStrField_19;
}

/**
 */
public class Test
{
    public static void main( String  [] prmArgs ) throws Exception
    {
        // !!! Test code BEGIN
        ///*
    String lclSrcStr =  "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789" +
                        "0123456789012345678901234567890123456789012345678901234567890123456789";
            //*/
        ///*
        String lclCrntStr = "";

        DbTestClass lclTestClass = null;

        while( lclCrntStr.length() < lclSrcStr.length() )
        {
            System.out.println("Len = "+lclCrntStr.length());

            Database lclDatabase = new DatabaseJNI();

            lclDatabase.open("Merck.dbs",32*1024,1024,1024);

            if( lclTestClass == null )
            {
                lclTestClass = new DbTestClass();

                lclTestClass.imvData        = lclCrntStr.getBytes("UTF-8");
                lclTestClass.imvStrField_1  = "0123456789";
                lclTestClass.imvStrField_2  = "0123456789";
                lclTestClass.imvStrField_3  = "0123456789";
                lclTestClass.imvStrField_4  = "0123456789";
                lclTestClass.imvStrField_5  = "0123456789";
                lclTestClass.imvStrField_6  = "0123456789";
                lclTestClass.imvStrField_7  = "0123456789";
                lclTestClass.imvStrField_8  = "0123456789";
                lclTestClass.imvStrField_9  = "0123456789";

                lclTestClass.imvKey  = lclDatabase.insert(lclTestClass);

                lclDatabase.update(lclTestClass.imvKey,lclTestClass);
            }
            else
            {
                Cursor lclCursor = lclDatabase.select(DbTestClass.class,"imvKey ="+lclTestClass.imvKey,0);

                if( lclCursor.hasMoreElements() )
                {
                    lclTestClass = (DbTestClass)lclCursor.nextElement();

                    //String lclData = new String(lclTestClass.imvData,"UTF-8");
                    String lclData = new String(lclTestClass.imvData);

                    if( lclData.compareTo(lclCrntStr) != 0 )
                    {
                        System.out.println(lclData);
                        System.out.println("ERROR: String is broken");
                        System.out.println(lclCrntStr);

                        System.exit(100);
                    }

                    lclCrntStr += lclSrcStr.charAt(lclCrntStr.length());

                    lclTestClass.imvData = lclCrntStr.getBytes("UTF-8");

                    lclDatabase.update(lclTestClass.imvKey,lclTestClass);
                }
                else
                {
                    System.out.println("ERROR: Sample not found"); System.exit(100);
                }
            }

            lclDatabase.close();

            lclDatabase = null;
        }

        System.out.println("SUCCESS: Finished"); System.exit(0);
    }
}
