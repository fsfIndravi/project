#!/bin/sh

rm -f *.dbs
./localclitest
./testalter
./testbatch
./testddl
./subsql testddl.sql
./testddl
./testidx
./testidx2
./testindex
./testiref
./testleak
./testperf
./testperf2
./testraw
./testsort
./testspat
./teststd
./testsync
./testblob *.cpp
./testblob *.cpp
./testreplic master1 & ./testreplic slave

