import jnicli.Database;
import jnicli.DatabaseJNI;

public class Gig {
	
	final static int poolSize = 5*1024;
	
	public static void main(String[] args) {
		
		Database db = new DatabaseJNI();
		db.open("test.dbs", poolSize, 0, 0);
		
		study st = new study();
		st.name = "teststudy";
		
		st.oid = db.insert(st);
		db.commit();
		System.out.println("Inserted study oid: " + st.oid);
		
		
		sample sa = new sample();
		sa.name = "testsample";
		sa.studyRef = st.oid;
		
		sa.oid = db.insert(sa);
		db.commit();
		System.out.println("Inserted sample oid: " + sa.oid);
		
		db.close();
		
	}
}

class study {
	static final String CONSTRAINTS = "name using index";
	public transient long oid;
	public String name;
}

class sample {
	static final String CONSTRAINTS = "studyRef references study using index";
	public transient long oid;
	public String name;
	public long studyRef;
}


