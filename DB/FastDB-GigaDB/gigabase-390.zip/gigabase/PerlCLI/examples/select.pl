#! /usr/bin/perl -w
# Example 1
# select to binded variables
 use strict;
 use Gigabase;
 my $con=new Gigabase::Connection('localhost',6100,'guest','guest') 
   || die "$Gigabase::errstr\n";
 {
  my $statm=$con->create_statement('select * from r') || die $con->errstr;
  my ($name,$one,$two,$three);
  $statm->bind_column("name",\$name);
  $statm->bind_column("one",\$one);
  $statm->bind_column("two",\$two);
  $statm->bind_column("three",\$three);
  my $typles=$statm->fetch();
  die $statm->errstr unless defined($typles);
  print "num of tuples " , $typles ,"\n";
  while ($statm->get_next()) {
   print "name=$name one=$one two=$two three=$three\n";
  }
 } #statement automatically freed
 $con->commit;
 $con->close();
