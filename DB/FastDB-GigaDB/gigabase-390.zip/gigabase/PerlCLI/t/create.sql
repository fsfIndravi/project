open 'perltest.dbs';
create table r ( name string,one real8,two real4,three int4);
insert into r values ('maza',1.234,5.678,4);
insert into r values ('faka',3.33,4.4,9);
commit;

create table person (name    string,
	             salary  int4,
	             address string,
                     rating  real8);
create index on person.salary;
create hash on person.name;
