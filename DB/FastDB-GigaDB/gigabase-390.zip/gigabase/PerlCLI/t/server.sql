open 'perltest.dbs';
start server 'localhost:6100' 8
